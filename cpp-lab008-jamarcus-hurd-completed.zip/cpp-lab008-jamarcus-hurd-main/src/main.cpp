#include "project/binary_search_tree.h"
#include <iostream>
#include <vector>

void printValues(const char* label, const std::vector<int>& values) {
    std::cout << label;
    for (int value : values) std::cout << ' ' << value;
    std::cout << '\n';
}

int main() {
    BinarySearchTree tree;
    for (int value : {50, 30, 70, 20, 40, 60, 80}) tree.insert(value);
    printValues("Inorder:", tree.inorderTraversal());
    printValues("Preorder:", tree.preorderTraversal());
    printValues("Postorder:", tree.postorderTraversal());
    std::cout << "Size: " << tree.size() << "\nHeight: " << tree.height()
              << "\nMinimum: " << tree.minimum() << "\nMaximum: " << tree.maximum()
              << "\nSearch 40: " << (tree.search(40) ? "found" : "not found") << '\n';
    tree.remove(50);
    printValues("After removing 50:", tree.inorderTraversal());
    std::cout << "Size after removal: " << tree.size() << '\n';
}
