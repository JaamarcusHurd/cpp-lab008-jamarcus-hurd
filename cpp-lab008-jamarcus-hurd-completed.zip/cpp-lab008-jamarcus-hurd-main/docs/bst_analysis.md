# Binary Search Tree Complexity Analysis

The tree stores integer keys in dynamically allocated nodes. Each node has a left and right pointer; keys smaller than a node go left, and larger keys go right. Duplicate insertions are rejected. Height is counted in **nodes** (empty = 0, one node = 1), matching the provided tests.

| Operation | Balanced / typical shape | Worst-case skewed shape |
| --- | --- | --- |
| Insert | O(log n) | O(n) |
| Search / contains | O(log n) | O(n) |
| Remove | O(log n) | O(n) |
| Minimum / maximum | O(log n) | O(n) |
| Inorder / preorder / postorder | O(n) | O(n) |
| Height calculation | O(n) | O(n) |
| Empty / size | O(1) | O(1) |

Insertion, searching, and deletion follow a path from the root, so their runtime is **O(h)** where h is the tree height. A reasonably balanced tree has height O(log n). If keys are inserted in sorted order, an ordinary BST can become a chain of n nodes, making these operations O(n). An immediate root match is O(1), but that does not describe typical searches. This implementation does not rebalance itself; AVL or red-black trees are better when guaranteed logarithmic height is needed.

Deletion has three cases. A leaf is deleted directly; a node with one child is replaced by its child; a node with two children is replaced with the smallest value from its right subtree, and that successor node is removed. The public remove method decrements the stored size only when the key existed. All three traversals visit every node, giving O(n) time. Height also visits every node. The destructor uses postorder deletion so children are released before parents.

Recursive code closely matches the branching structure of a tree and is concise, but uses O(h) call-stack space; on a highly skewed tree it can risk stack overflow. Iterative search and insertion can use loops and O(1) auxiliary space. An iterative traversal typically uses an explicit stack of O(h) space. The nodes themselves require O(n) memory. Copy construction and assignment are disabled to avoid shallow-copying owning pointers and double deletion.
